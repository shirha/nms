from inspect import currentframe, getframeinfo
import sys
import json
import re
import getopt 
ilog = 0
dbug = ''
title = 'Demo'
argv = sys.argv[1:] 
try: 
  opts, args = getopt.getopt(argv, "f:t:d:", ["file =", "title =", "dbug ="]) 
except: 
  print("SYNTAX: python pipj.py -f 0|1|2|t -t title") 
for opt, arg in opts: 
  if opt in ['-f', '--file']: 
    ilog = arg 
  elif opt in ['-t', '--title']: 
    title = arg 
  elif opt in ['-d', '--dbug']: 
    dbug = arg 
print(f'{sys.argv}')

def legend(sc,t,hn,ai,jf,cc):
  return "".join([
    f'<img src="i/badge-{sc}.png"/>&hairsp;',    
    f'<img src="i/badge-{t}.png"/>&hairsp;',    
    f'<img src="i/badge-{(["hn2","ai"])[ai==1]}.png"/> ',    
    f'<img src="i/class-{cc}.png"/>'])

badges = {
  "Nitogu":   legend(**{'sc':'b','t':2,'hn':1,'ai':0,'jf':1,'cc':'c'}),
  "Achara":   legend(**{'sc':'g','t':2,'hn':0,'ai':1,'jf':1,'cc':'c'}),
  "Lolringor":legend(**{'sc':'g','t':2,'hn':0,'ai':1,'jf':1,'cc':'a'}),
  "Suitaak":  legend(**{'sc':'y','t':2,'hn':1,'ai':0,'jf':1,'cc':'b'}),
  "Doludes":  legend(**{'sc':'y','t':2,'hn':0,'ai':1,'jf':1,'cc':'b'}),
  "Erlingdi": legend(**{'sc':'y','t':2,'hn':0,'ai':1,'jf':1,'cc':'c'})
}

pirates = set() # {"Odusha","Bandab"}
atlas = {"Yelobarn","Yusvadbeat XII","Bandab"}
poi = {
  "Nokyotomen":      ["Stellar Classification: F"],
  "Gejinme":         ["Stellar Classification: B"],
  "Skappe-Asoes V":  ["Stellar Classification: E"],
  "Hashir":          ["Stellar Classification: M"],
  "Ikoka 45/G1":     ["POI: <div class='poi rd'>Predators</div> <img src='i/paws.png'/>"],
  "Vistiraqu Hanai": ["POI: <div class='poi rd'>Predators</div> <img src='i/paws.png'/>"],
  "Oupol III":       ["POI: <div class='poi bl'>Storm Crystals</div> <img src='i/crystals.png'/>"],
  "Oyook 52/G8":     ["POI: <div class='poi gr'>Curious Deposit</div> <img src='i/curious.png'/>"],
  "Poor":            ["Original Name: <div class='poi on'>Kearbo-Nagyan</div>"],
  "Base":            ["Original Name: <div class='poi on'>Daytosira XIV</div>"],

  "Wibordo VI":      ["POI: <div class='poi bl'>Storm Crystals</div> <img src='i/crystals.png'/>"],
  "Onrovi":          ["POI: <div class='poi bl'>Storm Crystals</div> <img src='i/crystals.png'/>"],
  "Pipinugst":       ["POI: <div class='poi bl'>Storm Crystals</div> <img src='i/crystals.png'/>"],

  "Hunslowe":        ["POI: <div class=\"poi yl\">Ms 1.7</div> <div class=scx>r1</div> Archive <div class=sca>-28.04, +144.27</div>"],
  "Spinarr Kesen":   ["POI: <div class=\"poi yl\">Ms 2.7</div> <div class=scx>r2</div> Portal <div class=sca>-12.89, +67.56</div>"],
  "Bandab":          ["<div class=scp><b>Distance:</b></div> 8 ly &rarr; Doriguc VII"],
  "Haku 57/Q1":      ["POI: <div class=\"poi yl\">Ms 3.7</div> <div class=scx>r3</div> Crashed Freighter <div class=sca> -20.97, -85.18</div>"],
  "New Wadhabie":    ["POI: <div class=\"poi yl\">Ms 4.7</div> <div class=scx>r4</div> Portal <div class=sca> +32.94, +179.59</div>",
                      "POI: <div class=\"poi yl\">Ms 4.5</div> Palate Cleanser",
                      "<blockquote>Bake some biscuits</blockquote><div>"
                      "Sweet Root &rarr; Processed Sugar<br>"
                      "Heptaploid Wheat &rarr; Refined Flour<br>"
                      "Processed Sugar + Refined Flour &rarr; Sugar Dough<br>"
                      "Sugar Dough + Salt &rarr; Salty Cruncher</div>",
                      "<div class=\"poi tr\">Reward:</div> 2&times; S-class Mining Beam",
                      "POI: <div class=\"poi yl\">Ms 5.1</div> The Fallen",
                      "<blockquote>Visit traveler gravesite</blockquote>",
                      "<div class=\"poi tr\">Tip:</div> 820u West of <div class=scx>r4</div> Portal",
                      "<div class=\"poi tr\">Reward:</div> Indium Hyperdrive"],
  "Gartfol X":       ["POI: <div class=\"poi yl\">Ms 3.5</div> Assembly Required",
                      "<blockquote>Manufactured Liquid Explosives</blockquote><div>"
                      "Cactus Flesh &times;200 &raquo; Unstable Gel &times;1<br>"
                      "Mordite &times;25 + Fungal Mould &times;200 &raquo; Acid &times;1<br>"
                      "Acid &times;1 + Unstable Gel &times;1 &raquo; Liquid Explosive &times;1</div>",
                      "<div class=\"poi tr\">Tip:</div>", 
                      "<div>Okubun-Chadr // Aratae XIV &rarr; Fungal Mould</div>",
                      "<div>Faecium x3 &rarr; Mordite x2</div>",
                      "<div class=\"poi tr\">Reward:</div> S-class Movement"],
  "Yovetrowl III":   ["POI: <div class=\"poi bl\">Storm Crystals</div>",
                      "POI: <div class=\"poi yl\">Ms 4.3</div> Radiant Flight",
                      "<blockquote>Repair a crashed interceptor</blockquote>",
                      "<div class=\"poi tr\">Base:</div> Bucefaldkowo <div class=sca>+19.47, +13.66</div>"],
  "Mazuna":          ["<div class=scp><b>Original Name:</b></div> Mazuna-Puqia",
                      "<div class=scp><b>Distance:</b></div> 26 ly &rarr; Bandab"],
  "Onana":           ["POI: <div class=\"poi yl\">Ms 4.3</div> Radiant Flight",
                      "<blockquote>Repair a crashed interceptor <div class=\"sca n\">+44.42, +25.95</div></blockquote>"],
  "Yusvadbeat XII":  ["POI: <div class=\"poi yl\">Ms 2.5</div> To Infinity",
                      "<blockquote>Enter a black hole</blockquote>",
                      "<div><div class=scp><b>Distance:</b></div> 12 ly &rarr; Ilnyev</div>"],
  "Upacton Sigma":   ["POI: <div class=\"poi yl\">Ms 5.4</div> Xenophile",
                      "<blockquote>Discover exotic creatures: 1</blockquote>"],
  "Boeot Prime":     ["POI: <div class=\"poi yl\">Ms 5.7</div> <div class=scx>r5</div> Portal <div class=sca> +27.44, +11.24</div>"],
}  

dangerous = { # set
  # Weather
  "Acidic Deluges",
  "Blasted Atmosphere",
  "Blighted Planet",
  "Blistering Floods",
  "Billowing Dust Storms",
  "Bone-Stripping Acid Storms",
  "Cataclysmic Monsoons",
  "Corrosive Rainstorms",
  "Corrosive Storms",
  "Caustic Floods",
  "Dangerously Toxic Rain",
  "Deep Freeze",
  "Drifting Firestorms",
  "Extreme Radioactivity",
  "Icy Tempests",
  "Inferno Winds",
  "Intense Cold",
  "Intense Heatbursts",
  "Lung-Burning Night Wind",
  "Magma Rain",
  "Painfully Hot Rain",
  "Particulate Winds",
  "Roaring Ice Storms",
  "Scalding Rainstorms",
  "Self-Igniting Storms",
  "Superheated Rain",
  "Torrential Acid",
  "Torrential Heat",
  "Toxic Monsoons",
  "Winds from Beyond",
  # Sentinel
  "Aggressive",
  "Frenzied",
  "High Security",
  "Hostile Patrols",
  "Hateful",
  "Inescapable",
  "Threatening",
  "Zealous",
  #Corrupted
  "Answer To None",
  "Corrupted",
  "De-Harmonised",
  "Dissonant",
  "Forsaken",
  "Rebellious",
  "Sharded from the Atlas",
  #Contraband
  "Banned Weapons",
  "Blood Salt",
  "Counterfeit Circuits",
  "First Spawn Relics",
  "GrahGrah",
  "Moon Ether",
  "NipNip Buds",
  "Prismatic Feathers",
  "Stolen DNA Samples"
}

corrupted = {  #Corrupted
  "Answer To None",
  "Corrupted",
  "De-Harmonised",
  "Dissonant",
  "Forsaken",
  "Rebellious",
  "Sharded from the Atlas"
}

checklist = '''
<div style="color:#551a8b;"><small><br>
* Only the top class upgrades are shown in the System Summary<br>
System Detail only shows upgrades found in System Summary<br>
<br>
Technology, Buy Sell, Resources and Biome are now clickable<br>
The top item in the popup scrolls to the top when clicked<br>
You must click one of the popup links to dismiss the popup<br>
You can click other clickable items while popup is visible

</small></div>
<h2 style="display:none; padding-top: 8px;">Checklist -- see e12 Omega</h2>
'''

h = ['''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="mobile-web-app-capable" content="yes">
  <title>{0}</title>
<style> 
@font-face {font-family: "NMS Geo"; src: url("geonms-webfont.ttf");}
@font-face {font-family: "NMS Glyphs"; src: url("NMS-Glyphs-Mono.ttf");}
h2 {text-align: center; max-width: 800px; font-size: 1.25em;}
body {background: url("screenshot.jpg") fixed no-repeat; background-size: cover; font-size: 18px;}
table {border-spacing: 0;}
td {padding: 0;}
td {vertical-align: top;}
div {padding-left: 10px;}
img {height: 18px; vertical-align: middle; margin-bottom: 4px; margin-left: 4px;}
.poi {display: inline-block; border-radius: 8px; padding: 0 8px; margin: 1px 0; font-style: normal;}
.bio {padding-left:30px;}
.cc {height: 24px; margin: 0; padding-left: 0;}
.badge {display: inline-block; padding: 0;}
.badge div {display: inline-block; padding: 0;}
.bq {font-style: italic; color: #551a8b;} /* navy;} */
blockquote {margin: 0; padding: 0 10px; font-style: italic; color: #551a8b;} /* navy;} */
button {font-size: 18px; padding: 2px 10px; margin-top: 15px; border-radius: 8px; border: 1px solid #222; background-color: greenyellow;}
.gl {font-family: "NMS Glyphs"; font-size: larger; font-weight: bold; height: 22px; display: inline-block; padding:0;} 
span {font-family: "NMS Glyphs"; font-size: larger; font-weight: bold;} 
.k {font-family: "NMS Kerned"; font-weight: bold;} 
.disabled {font-family: "NMS Glyphs"; font-size: larger; font-weight: bold; color: #a0a0a0;} 
.dot {border-radius: 50%; height: 10px; width: 10px; display: inline-block; margin-left: 4px; padding: 0; border: 1px solid #aaa;}
.dox {border-radius: 50%; height: 10px; width: 10px; display: inline-block; margin-left: 4px; padding: 0;}
.fl td::first-letter {font-weight: normal;}
.c {display: inline-block; vertical-align: top; padding-top: 8px;}
.s, .p {padding-top: 8px;} 
.sy {display: inline-block; font-family: Arial;}
.pl {display: inline-block;}
.pl:link {color: #551a8b;} .pl:visited {color: #551a8b} .pl:hover {color: #0000ee;}
.sy:link {color: #0000ee;} .sy:visited {color: #0000ee} .sy:hover {color: #551a8b;}
a {color:black; white-space: nowrap; border-radius: 6px; padding: 1px 6px; text-decoration: none; margin-bottom: 1px; border: 1px solid #808080; cursor: pointer;}
.tbl {display: inline-block; padding-left: 0; width:130px;}
.pg  {border: 0; padding: 0;}
.pg img {vertical-align: top;}
#sum {border-spacing: 4px 4px; border-collapse: separate;}
/*#sum td {padding-bottom: 0px;}*/
.r {margin-top: 10px;}
.pu {font-style: italic; color: purple; padding-left: 0; display: inline-block;}
.tc,.ib,.scp {padding:0; cursor: pointer;}
.bc {cursor: pointer;}
.ab {background-color: #E1C16E;}
.ab,.ac {border:0;}
.at {background-color: #f0f0f0;} /* #ffe9b3;} */
.tc div, .content div {display: inline-block; border: 1px solid #bbb; width: 13px; border-radius: 4px;  
    text-align: center; padding: 0 2px; font-size: 14px; font-family: 'NMS Geo'}
.sca {display: inline-block; padding-left: 0; color:#0000ee}
.scx {display: inline-block; padding-left: 0; color: #600080; font-family: Arial; font-variant: small-caps; /*font-weight:bold; font-style: italic; border: 1px solid darkgrey; border-radius: 8px;padding: 0 6px;*/}
.scy {display: inline-block; padding-left: 0; color:yellow}
.sms {display: inline-block; color:black; font-style: normal; padding: 0; font-family: Arial; font-size: 18px; font-variant: small-caps;}
.scr {display: inline-block; padding-left: 0; color:#DC143C}
.scg {display: inline-block; padding-left: 0; color:limegreen}
.scb {display: inline-block; padding-left: 0; color:blue}
.sct {display: inline-block; padding-left: 0; color:teal}
.scp {display: inline-block; padding-left: 0; color:purple}
.tgb {background-color: blue;}      /* blue */
.bl  {background-color: #b0e0ff;}   /* storm crystal */
.tcb {background-color: #aad9f7;}   /* tech class b */
.tgg {background-color: limegreen;} /* green */
.tcc {background-color: #99ff66;}   /* tech class c */
.gr  {background-color: #99ff66;} 
.tr  {background-color: greenyellow; color: black;}  /* traveler - #BD104C;  */
.tgr {background-color: #de143c;}   /* red */
.tcs {background-color: #ffc100;}   /* tech class s */
.bh  {background-color: #E1C16E;}   /* black hole */
.rd  {background-color: pink;}      /* predator */
.yl  {background-color: yellow;} 
.tgy {background-color: yellow;} 
.br  {background-color: #D2B48C;}   /* horrific nest */
.co  {background-color: #d9b3ff;}   /* #debde4; corrupted */
.tca {background-color: #d9b3ff;}   /* tech class a */
.tcx {background-color: #ddd;}      /* tech class x */
.on  {background-color: #f8f8f8;}   /* #f8f8f8 */
.bca {background-color: #d9b3ff; border-radius: 8px;}
#option1 {display:block;}
#option2 {display:none;}

.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  max-width: 800px;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
}
.modal img {width: 80%; height: auto; margin: 10%;}

#id01 {background-color: #474e5d;}
#id02 {background-color: rgb(224, 224, 224,0.8);}
#al tr:nth-child(1) td {border-bottom: 1px solid #98e2e2;}
#al {margin: 16px; background-color: white; border: 1px solid #98e2e2; border-radius: 4px;}
#container {max-width: 900px; padding: 0;}

.content { 
  position: fixed;
  left: 100%;
  top: 50%;
  -webkit-transform: translate(-100%, -50%);
  transform: translate(-100%, -50%);
  border-radius: 4px;
  padding:0;
}

@media (min-width: 600px) {
  .content {
    left: 600px;
  }
}
/*
.content { 
  position: fixed;
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  border-radius: 8px;
  padding:0;
}
@media (min-width: 740px) {
  .content {
    left: 370px;
  }
}
*/
</style></head><body><div id="container">
<div id="id01" class="modal">
  <img src="i/help.png">
</div>
<div id="id02" class="content"></div>
''']

id = 0
def inc(): 
  global id
  id += 1
  return f'{id:03d}'

dict_ = {"F":"tgy","G":"tgy","K":"tgr","M":"tgr","B":"tgb","O":"tgb","E":"tgg"}
def tags(station):
  html = [station]
  for text in db[station]["System Info"]:
    if "Pirate Controlled" in text:
      html.append('<img src="i/pirate_icon.png">')
    if "Stellar Classification" in text and text[24] in dict_:
      html.append(f'<div class="dox {dict_[text[24]]}"></div>')
  if station in atlas:
    html.append('<img src="i/atlas_icon.png">')
  html.append(dot(station))
  return "".join(html)

# use on System Summary only
dot    = lambda p: ('','<div class="dox yl"></div>')[p in poi and any(re.match('POI', x) for x in poi[p])]
ptag   = lambda p: f'\n  <a class="pl">{p}{dot(p)}</a>'
stag   = lambda p: f'<a class="sy">{tags(p)}</a>'

with open(f'pip{ilog}.json', "r") as infile: 
  db = json.load(infile)

  for s in db:
    db[s]['Technology'] = sorted(db[s]['Technology'].keys(),key=lambda x:x[3:])
    db[s]['Buy Sell'  ] = sorted(db[s]['Buy Sell'  ].keys())

    # add points of interest; 
    if s in poi:
      # if "Original Name:" in poi[s][0]:
      #   db[s]['System Info'].insert(0, poi[s][0])
      # else:
        db[s]['System Info'].extend(poi[s])

    for p in db[s]:
      if p in poi:
        db[s][p]['Planet Info'].extend(poi[p])
        if dbug: print(getframeinfo(currentframe()).lineno, f's={s}, p={p}, poi[p][0]={poi[p][0]}')

  h.append('<h2>{0} System Summary</h2>')
  h.append('<table id=sum><tr><th>Systems</th><th>Planets</th></tr>')

  nl = '\n'
  sum = {}
  spelling = {}
  for station in db:
    print(station)
    planets = []
    for planet in db[station].keys():
      if not planet in ["System Info","Technology","Buy Sell"]:
        planets.append(planet)
        p = list(filter(lambda x: 'Biome:' in x, db[station][planet]['Planet Info']))
        print(f'!! {p}, #{planet}')
        if p: 
          item = p[0][7:]
          if not item in spelling:
            spelling[item] = 0
          spelling[item] += 1
    h.append(f'<tr><td nowrap>{badges[station] if station in badges else ""} {stag(station)}</td><td>{" ".join(map(ptag, planets))}</td></tr>')
  h.append('</table>')
  sum['Biome'] = b = sorted(spelling.keys())

  spelling = {}
  for station in db:
    for item in db[station]['Technology']: 
      m = re.search(r'(...)(.+)', item)
      if not m.group(2) in spelling:
        spelling[m.group(2)] = []
      spelling[m.group(2)].append(m.group(1))

    #-------------------------- sort tech class within item (in place) ---------------------------
    for item in spelling:
      spelling[item].sort(key=lambda x:'SABCX'.index(x[1]))

  sum['Technology'] = sorted([spelling[i][0] + i for i in spelling], key=lambda x: x[3:])
  tech_set = {i for i in sum['Technology']}

  for station in db:
    #-------------------------- show all Suspicious, don't filter ---------------------------
    if not any("Pirate Controlled" in x for x in db[station]["System Info"]):
      db[station]['Technology'] = filter(lambda x: x in tech_set, db[station]['Technology'])
      #-------------------------- show only tech in system summary --------------------------

  spelling = {}
  for station in db:
    for item in db[station]['Buy Sell'  ]: 
      if not item in spelling: 
        spelling[item] = 0
      spelling[item] += 1
  sum['Buy Sell'] = sorted(spelling.keys())

  spelling = {}
  for station in db:
    for planet in db[station]:
      if not planet in ["System Info","Technology","Buy Sell"]:
        for item in db[station][planet]['Resources']:
          if not item in spelling: 
            spelling[item] = 0
          spelling[item] += 1
  sum['Resources'] = sorted(spelling.keys())

  def contraband(sum):                                                                              # (answer tuple)[truth index]
    return map(lambda i: (f'<div class="ib" id="_s{inc()}">{i}</div>', f'<div class="scp" id="_s{inc()}">{i}</div>')[i in dangerous],sum)
      
  def dissonance(sum):
    return map(lambda i: (f'<div class="ib" id="_r{inc()}">{i}</div>', f'<div class="scp" id="_r{inc()}">{i}</div>')[i == 'Dissonance detected'],sum) 

  def decorate_tech(sum):
    rows = []
    for item in sum:
      m = re.search(r'.(.).(.+)', item)
      rows.append(f'<div class="tc" id="_t{inc()}"><div class="tc{m.group(1).lower()}">{m.group(1)}</div>&hairsp;{m.group(2)}</div>\n')
    return ''.join(rows)

  def biome(sum):
    return map(lambda i: f'<div class="ib" id="_b{inc()}">{i}</div>', sum)

  h.append(f'<div class=c><center><b>Technology</b></center>{decorate_tech(sum["Technology"])}</div>')
  h.append(f'<div class=c><center><b>Buy Sell</b></center>{nl.join(contraband(sum["Buy Sell"]))}</div>')
  h.append(f'<div class=c><center><b>Resources</b></center>{nl.join(dissonance(sum["Resources"]))}</div>')
  h.append(f'<div class=c><center><b>Biome</b></center>{nl.join(biome(sum["Biome"]))}</div>')

  # ---------------------------------------------------------------------------------

  h.append('<h2>{0} System Detail</h2>')
  for s in db:
    p = re.sub(" ","_",s) 
    h.append(f'<div class="s" id="{p}">{badges[s] if s in badges else ""} <a class="sy">{s}</a>')
    for c in db[s]:
      p = re.sub(" ","_",c)
      if c in ["System Info","Technology","Buy Sell"]:
        h.append(f'  <div>{c}')
      else:
        h.append(f'  <div class="p" id="{p}"><a class="pl">{c}</a>')

      for i in db[s][c]:
        # print(f'{s}, {c}, {i},')
        if c in ["System Info","Technology","Buy Sell"]:
          i = re.sub(r'(Glyphs: )([\da-f]{6})([\da-f]{6})',r'\1<div class=gl>\2&nbsp;\3</div>', i)
          #-------------------------- contraband ---------------------------------------------
          if c == "Buy Sell":
            if i in dangerous:
              h.append(f'      <div><div class="scp" id="_s{inc()}">{i}</div></div>')
            else:
              h.append(f'      <div class="bc" id="_s{inc()}">{i}</div>')
          else:
          #-------------------------- upgrade class ------------------------------------------
            if c == "Technology":
              m = re.search(r'.(.).(.+)', i) # see decorate_tech
              h.append(f'    <div class="tc" id="_t{inc()}"><div class="tc{m.group(1).lower()}">{m.group(1)}</div>&hairsp;{m.group(2)}</div>')
            else:
              if "Stellar Classification" in i and i[24] in dict_:
              # html.append(f'<div class="dox {dict_[text[24]]}"></div>')
                h.append(f'    <div>{i}<div class="dox {dict_[i[24]]}"></div></div>')
              else:
                h.append(f'    <div>{i}</div>')
        else: 
          # print(f'c={c}')
          h.append(f'    <div>{i}')

          for j in db[s][c][i]:
            # print(f'{s}, {c}, {i}, {j}')
            if i == 'Planet Info':
              if dbug: print(getframeinfo(currentframe()).lineno, f's={s}, c={c}, i={i}, j={j}')
              #--------------------------- dangerous -------------------------------------------
              m = re.search(r'^((Weather|Sentinels): )(.+)$',j)
              if m and m.group(3) in dangerous:
                print("dangerous= ",m.group(1),m.group(3))
                if(m.group(2) == "Sentinels" and m.group(3) in corrupted):
                  h.append(f'      <div>{m.group(1)}<div class="poi co">{m.group(3)}</div></div>')
                else:
                  h.append(f'      <div>{m.group(1)}<div class="poi rd">{m.group(3)}</div></div>')
              else:
                if 'Biome:' in j:
                  h.append(f'      <div class="bc" id="_b{inc()}">{j}</div>')
                else:
                  h.append(f'      <div>{j}</div>')
            #--------------------------- dissonance ------------------------------------------
            if i == 'Resources':
              if j == 'Dissonance detected':
                print(getframeinfo(currentframe()).lineno, f's={s}, c={c}, i={i}, j={j}')
                h.append(f'      <div><div class="scp" id="_r{inc()}">{j}</div></div>')
              else:
                h.append(f'      <div class="bc" id="_r{inc()}">{j}</div>')
              # else:
              #   h.append(f'<!--3--><div>{j}</div>')

            #---------------------------------------------------------------------------------
          h.append('    </div>')
      h.append('  </div>')
    h.append('</div>')
h.append('''<button>Collapse All</button>
{1}
<div style="margin-top: 700px;"></div>
</div> <!-- end container -->
<script>
const links={2}

function findLinks(links, key) {
  const firstItem = links[key][0];
  const matchingKeys = [];
  for (const k in links) {
    if (links.hasOwnProperty(k) && links[k][0] === firstItem && k[1] == key[1]) {
      matchingKeys.push(k);
  } }
  return matchingKeys;
}

const id01 = document.getElementById('id01'),
  id02 = document.getElementById('id02'),
  handleModal = () => id01.style.display='block',
  handleLinks = (e) => {
    let docs = [];
    const urls = findLinks(links,e.target.id);
    urls.forEach((x,i) => {
      if(i == 0){
        docs.push(`<table id=al><tr><td class="at"><a class="ac" href="javascript:jump('0')">${links[x][0]}</a></td></tr>`);
      }else{
        docs.push(`<tr><td><a class="ac" href="javascript:jump('${links[x][1]}')">${links[x][1].replace(/_/g, ' ')}</a></td></tr>`);
      }
    });
    docs.push('</table>');
    id02.innerHTML = docs.join("\\n");
    id02.style.display='block';
  };

function jump(id){
  if(id == '0'){
    window.scrollTo(0, 0);
  }else{
    document.getElementById(id).scrollIntoView();
  }
  id02.style.display='none';
}

function sv(id){
  document.getElementById(id).scrollIntoView({ behavior: "smooth" });
}

[...document.querySelectorAll(".sy,.pl")]
  .forEach(e => {
    if(e.parentNode.tagName == 'TD'){
      const a_id = e.textContent.replace(/ /g, '_');
      e.addEventListener('click', function(e){
        document.getElementById(a_id).scrollIntoView()
      })
    }else{
      e.addEventListener('click', function(e){
        window.scrollTo(0, 0);
      })
    }
  });         

document.querySelector('button').addEventListener('click', function(){
  document.querySelectorAll('.c')
    .forEach(e => e.style.display = 'none');

  [...document.querySelectorAll('.p')]
    .filter(e => !/POI:/.test(e.textContent))
    .forEach(e => e.style.display = "none");

  document.querySelectorAll('.s')
    .forEach(e => {
      [...e.querySelectorAll('div')]
        .filter(e => /^(Technology|Buy Sell|Resources)/.test(e.textContent))
        .forEach(e => e.style.display = 'none')
    });
  document.querySelector('button').style.display = 'none';
});

let cbox = document.querySelectorAll('input[type=checkbox]');

for (let i = 0; i < cbox.length; i++) {
  cbox[i].addEventListener("click", function(e) {
    let key = e.target.nextSibling.nextSibling.innerHTML;
    if(localStorage.getItem(key) === null){
      localStorage.setItem(key, true);
      e.target.checked == true;
    }else{
      localStorage.removeItem(key);
      e.target.checked == false;
    }
  });

  ms = cbox[i].nextSibling.nextSibling.innerHTML;
  if(!(localStorage.getItem(ms) === null)){ 
    console.log(ms);
    cbox[i].checked = true;
  }
}

function clearCheckbox(){
  if(confirm("Are you sure?")){
    Object.keys(localStorage)
      .filter(key => /Ms \d\.\d/.test(key))
      .map(key => localStorage.removeItem(key));
    [...cbox].map(e => e.checked = false);
  }
}

[...document.querySelectorAll('img')]
  .filter(e => /badge|class/.test(e.src))
  .forEach(e => e.addEventListener('click', handleModal));

window.onclick = function(event) {
  if (event.target.parentNode == id01 || event.target == id01) {
    modal.style.display = "none";

    [...document.querySelectorAll('img')]
      .filter(e => /badge|class/.test(e.src))
      .forEach(e => e.removeEventListener('click', handleModal));
  // }else if(id02.style.display == "block"){
  //   id02.style.display = "none";
  }
};

[...document.querySelectorAll('div')]
  .filter(e => e.id.startsWith('_'))
  .forEach(e => e.addEventListener('click', handleLinks));

</script></body></html>''')

links = {}
sid = ''
pid = ''
for i in list(filter(lambda i: re.search(r'="sy|="pl|id="_',i),'\n'.join(h).splitlines())):
  # print('\t',i.strip())
  s = re.search(r'"s" id="([^"]+)',i)
  if s:
    sid = s.group(1)
    pid = ''
  else:
    p = re.search(r'"p" id="([^"]+)',i)
    if p:
      pid = p.group(1)
    else:
      m = re.search(r'<div class="ib" id="(_[srb]\d+)">([^<]+)</div>',i)
      if not m:
        m = re.search(r'<div class="bc" id="(_[rs]\d+)">([^<]+)</div>',i)
        if not m:
          m = re.search(r'<div class="scp" id="(_[rs]\d+)">([^<]+)</div>',i)
          if not m:
            m = re.search(r'<div class="tc" id="(_t\d+)">(<div class="tc.">.</div>[^<]+)</div>',i)
            if not m:
              m = re.search(r'<div class="bc" id="(_b\d+)">Biome: ([^<]+)</div>',i)
      if m:
        id, key, link = m.group(1), m.group(2), pid if pid else sid
        links[id]=[key,link]
        # print(f'"{id}":["{key}", "{link}"]','\n')
# print(json.dumps(links ,indent=2))

h = re.sub(r'\{0\}', title, '\n'.join(h))
h = re.sub(r'\{1\}', checklist, h)
h = re.sub(r'\{2\}', json.dumps(links), h)

with open(f'{title}.html','w') as outfile:
  outfile.write(h)
